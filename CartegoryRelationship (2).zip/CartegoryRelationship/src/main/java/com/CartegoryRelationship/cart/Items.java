package com.CartegoryRelationship.cart;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="ForeignKeyAssoItemsEntity")
@Table(name="Items_Details")
public class Items implements Serializable {
	
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int itemid;
	@Column(name="Item_Name")
	private String itemname;
	private float price;
	@Column(name="Stock_Number")
	private int stockno;
	private String Description;
	private String remarks;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="ITEM_ID")
	private List<PurchaseHistory> purchasehistory;
	
	public Items () {
		
		
	}

	public Items(int itemid, String itemname, float price, int stockno, String description, String remarks) {
		super();
		this.itemid = itemid;
		this.itemname = itemname;
		this.price = price;
		this.stockno = stockno;
		Description = description;
		this.remarks = remarks;
	}

	public int getItemid() {
		return itemid;
	}

	public void setItemid(int itemid) {
		this.itemid = itemid;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getStockno() {
		return stockno;
	}

	public void setStockno(int stockno) {
		this.stockno = stockno;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", itemname=" + itemname + ", price=" + price + ", stockno=" + stockno
				+ ", Description=" + Description + ", remarks=" + remarks + "]";
	}



}


