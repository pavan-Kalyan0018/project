package com.CartegoryRelationship.cart;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="ForeignKeyAssoBuyerEntity")
@Table(name="Buyer_Details")
public class BuyerDb implements Serializable {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int buyerid;
	@Column(name="User_Name")
	private String username;
	private String password;
	private String emailid;
	@Column(name="Mobile_NO")
	private int mobileno;
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date createddatetime;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="BUYER_ID")
	private List<PurchaseHistory> purchasehistoty;
	
	
	public BuyerDb() {
		
	}

	public BuyerDb(int buyerid, String username, String password, String emailid, int mobileno, Date createddatetime) {
		super();
		this.buyerid = buyerid;
		this.username = username;
		this.password = password;
		this.emailid = emailid;
		this.mobileno = mobileno;
		this.createddatetime = createddatetime;
	}

	public int getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public int getMobileno() {
		return mobileno;
	}

	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}

	public Date getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Date createddatetime) {
		this.createddatetime = createddatetime;
	}
	
	

	public List<PurchaseHistory> getPurchasehistoty() {
		return purchasehistoty;
	}

	public void setPurchasehistoty(List<PurchaseHistory> purchasehistoty) {
		this.purchasehistoty = purchasehistoty;
	}

	@Override
	public String toString() {
		return "BuyerDb [buyerid=" + buyerid + ", username=" + username + ", password=" + password + ", emailid="
				+ emailid + ", mobileno=" + mobileno + ", createddatetime=" + createddatetime + "]";
	}

	
	
}
