package com.egg.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.Idao;
import com.egg.dao.ItemsDao;
import com.egg.dao.PurchaseDao;
import com.egg.dao.TransactionDao;
import com.egg.model.BuyerDetails;
import com.egg.model.CartItems;
import com.egg.model.PurchaseHistory;
import com.egg.model.TransactionHistory;
import com.egg.service.Iservice;



@Service(value = "userService")
public class UserServices implements UserDetailsService,Iservice {
    @Autowired
    private Idao dao;
    @Autowired
    private ItemsDao itemsDao;
    @Autowired
    private TransactionDao transactionDao;
    @Autowired
    private PurchaseDao purchaseDao;
    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;
    
    
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerDetails buyer = dao.findByUsername(username);
		if(buyer == null){ 
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getUsername(), buyer.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

    
    
     //Buyers SERVICE
	  @Override 
	  public List<BuyerDetails> getAll() {
	  
	  return dao.findAll() ; 
	  }
	 @Override
	  public BuyerDetails addBuyer(BuyerDetails buyerdetails) {
		
		return dao.save(buyerdetails);
	 }
	 @Override
	 public BuyerDetails getBuyer(int id) {
		return dao.getOne(id);
	  }
	 @Override
	 public BuyerDetails updateBuyer(BuyerDetails buyerdetails,int id) {
		BuyerDetails buyerDetails1=dao.getOne(id);
		if(buyerDetails1!=null)
		{   
			int buyerbuyeId=buyerdetails.getBuyerID();
			String username=buyerdetails.getUsername();
			String password=buyerdetails.getPassword();
			String EmailId=buyerdetails.getEmailId();
			Date createddate=buyerdetails.getCreatedDate();
			String mobileNo=buyerdetails.getMobileNumber();
			System.out.println("enter into info");
			buyerDetails1.setBuyerID(id);
			buyerDetails1.setUsername(username);
			buyerDetails1.setPassword(password);
			buyerDetails1.setEmailId(EmailId);
			buyerDetails1.setCreatedDate(createddate);
			buyerDetails1.setMobileNumber(mobileNo);
			System.out.println(buyerDetails1.getEmailId());
			
			
		}
		else 
		{ 
			
		}
	return dao.save(buyerDetails1);

	
	
	}
     
	 
	 
	//Items SERVICE
	@Override
	public List<CartItems> getAllItems() {
		return itemsDao.findAll();
 	
	}
     @Override
	public CartItems addcart(CartItems cartItems,int id) {
		BuyerDetails buyerdetails=dao.getOne(id);
		cartItems.setBuyerDetailsId(buyerdetails);
		return itemsDao.save(cartItems);
	}
	@Override
	public CartItems getItem(int id) {
		return itemsDao.getOne(id);
	}
	@Override
	public CartItems updateItem(CartItems cartItems, int id) {
		CartItems cartItems1=itemsDao.getOne(id);
		if(cartItems1!=null)
		{
//			 int cartItemId=cartItems.getCartItemId();
			 int itemId=cartItems.getItemId();
			 int quantity=cartItems.getQuantity();
			 float price=cartItems.getPrice();
//			 cartItems1.setCartItemId(cartItemId);
			 cartItems1.setItemId(itemId);
			 cartItems1.setQuantity(quantity);
			
		}
		else
		{
			
		}
		return itemsDao.save(cartItems1);
	}
	@Override
	public  void deleteItem(int id) {
		 itemsDao.deleteById(id);
		 System.out.println("deleted sucessfully"+id);
	}
	@Override
	public void deleteAllItem() {
		itemsDao.deleteAll();
		 System.out.println("deleted all the items in the cart sucessfully");
		
	}

	
	
	//Transactions SERVICE
	@Override
	public List<TransactionHistory> getAllTransaction() {
		return transactionDao.findAll();
	}
	@Override
	public TransactionHistory addcartItems(TransactionHistory transactonhistory, int id) {
        BuyerDetails buyerdetails = dao.getOne(id);
        transactonhistory.setBuyerdetails(buyerdetails);
		return transactionDao.save(transactonhistory);
	}
	@Override
	public TransactionHistory getTransaction(int id) {
		return transactionDao.getOne(id);
	}
	@Override
	public TransactionHistory updateTransaction(TransactionHistory transactionhistory, int id) {
		TransactionHistory transactionhistory1 = transactionDao.getOne(id);
		if(transactionhistory1!=null)
		{
			int transactionId=transactionhistory.getTransactionId();
			String transactionType=transactionhistory.getTransactionType();
			Date dateTime=transactionhistory.getDateTime();
			String remarks=transactionhistory.getRemarks();
			transactionhistory1.setTransactionId(transactionId);
			transactionhistory1.setTransactionType(transactionType);
			transactionhistory1.setDateTime(dateTime);
			transactionhistory1.setRemarks(remarks);
		}
		else 
		{
			
		}
		
		return transactionDao.save(transactionhistory1);
	}
		
		
		//Purchasehistory SERVICE
	
	@Override
	public PurchaseHistory addPurchase(PurchaseHistory purchasehistory, int id,int ids) {
		BuyerDetails buyerDetails = dao.getOne(id);
		TransactionHistory transactionHistory = transactionDao.getOne(id);
		purchasehistory.setBuyerdetails(buyerDetails);
		purchasehistory.setTransactionhistory(transactionHistory);
		return purchaseDao.save(purchasehistory);
	}
	@Override
	public List<PurchaseHistory> getPurchase() {
		return purchaseDao.findAll();
	}
	@Override
	public PurchaseHistory getpurchase(int id) {	
		return purchaseDao.getOne(id);
	}
	@Override
	public PurchaseHistory updatePurchase(PurchaseHistory purchasehistory, int id) {
		PurchaseHistory purchasehistory1 = purchaseDao.getOne(id);
		if(purchasehistory1!=null)
		{
			int purchaseHistoryId=purchasehistory.getPurchaseHistoryId();
			int itemId=purchasehistory.getItemId();
			Date dateTime=purchasehistory.getDateTime();
			int numberOfItems=purchasehistory.getNumberOfItems();
			String remarks=purchasehistory.getRemarks();
			purchasehistory1.setDateTime(dateTime);
			purchasehistory1.setItemId(itemId);
			purchasehistory1.setNumberOfItems(numberOfItems);
			purchasehistory1.setRemarks(remarks);
			purchasehistory1.setPurchaseHistoryId(purchaseHistoryId);
		}
		else 
		{
			
		}
		
		return purchaseDao.save(purchasehistory1);
	}


	//CHECKOUTFOR CART
	
	
      	@Override
		public String checkout(TransactionHistory transactionhistory,int ids) {
		 BuyerDetails buyerdetails = dao.getOne(ids);
			 transactionhistory.setBuyerdetails(buyerdetails);
			 
 		 transactionDao.save(transactionhistory);
		List<CartItems> cartItems= itemsDao.getByBuyerId(ids);
			for(int i = 0; i < cartItems.size(); i++)
			{   
				CartItems cartitems =cartItems.get(i); 
				PurchaseHistory purchasehistory = new PurchaseHistory();
				Date dateOfTransaction=transactionhistory.getDateTime();
				purchasehistory.setPurchaseHistoryId(i);
				purchasehistory.setDateTime(dateOfTransaction);
				purchasehistory.setBuyerdetails(buyerdetails);
				int itemId=cartitems.getItemId();
				purchasehistory.setItemId(itemId);
				int numberOfItems = cartitems.getQuantity();
				purchasehistory.setNumberOfItems(numberOfItems);
				purchasehistory.setRemarks("good");
				purchasehistory.setTransactionhistory(transactionhistory);
				purchaseDao.save(purchasehistory);
				itemsDao.delete(cartitems);
				
			}
			return "Success";
		}
	
	
	
	/*
	 * public void checkoutCart(Integer buyerId) { Double totalAmount = 0.00;
	 * TransactionHistory transaction = null; PurchaseHistory purchaseHistory =
	 * null; ItemInventory cartItem = null;
	 * 
	 * List<ShoppingCart> getAllCart = cartRepository.getAllCartItems(buyerId);
	 * for(ShoppingCart cart : getAllCart) { Optional<ItemInventory> item =
	 * itemrepository.findById(cart.getItemId()); totalAmount +=
	 * item.get().getItemPrice(); } Optional<Buyer> buyer =
	 * buyerRepository.findById(buyerId); transaction = new TransactionHistory();
	 * transaction.setBuyerId(buyer.get()); transaction.setTotalAmount(totalAmount);
	 * transaction.setTransactionType("Debited");
	 * transaction.setTransactionRemarks("PaymentDone");
	 * 
	 * transactionRepository.save(transaction);
	 * 
	 * purchaseHistory = new PurchaseHistory(); for(ShoppingCart cart : getAllCart)
	 * { purchaseHistory.setTransactionHistory(transaction);
	 * purchaseHistory.setItemId(cart.getItemId());
	 * purchaseHistory.setBuyerId(buyer.get());
	 * purchaseHistory.setPurchaseRemarks("purchased");
	 * purchaseHistory.setNumberOfItems(cart.getItemQuantity()); cartItem = new
	 * ItemInventory(); Optional<ItemInventory> newitem =
	 * itemrepository.findById(cart.getItemId()); cartItem = newitem.get(); Long
	 * quantity = cartItem.getItemStockNumber();
	 * cartItem.setItemStockNumber(quantity-cart.getItemQuantity());
	 * itemrepository.save(cartItem); purchaseRepository.save(purchaseHistory); } }
	 * 
	 * 
	 */


	

}
