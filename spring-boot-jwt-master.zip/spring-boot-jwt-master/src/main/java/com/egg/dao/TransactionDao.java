package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.TransactionHistory;



public interface TransactionDao extends JpaRepository<TransactionHistory, Integer>{

}
