package com.cts.springbootjpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
//@Table(name="PurchaseHistory_Details")
public class PurchaseHistory implements Serializable {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int purchaseid;
	@Column(name="No_of_Items")
	private int noofitems;
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date datetime;
	private String remarks;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ITEM_ID")
	private Items items;
	
	
	
	public PurchaseHistory() {
		
	}

	public PurchaseHistory(int purchaseid, int noofitems, Date datetime, String remarks) {
		super();
		this.purchaseid = purchaseid;
		this.noofitems = noofitems;
		this.datetime = datetime;
		this.remarks = remarks;
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}

	public int getNoofitems() {
		return noofitems;
	}

	public void setNoofitems(int noofitems) {
		this.noofitems = noofitems;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Items getItems() {
		return items;
	}

	public void setItems(Items items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseid=" + purchaseid + ", noofitems=" + noofitems + ", datetime=" + datetime
				+ ", remarks=" + remarks + "]";
	}	

}
