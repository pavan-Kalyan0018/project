package com.cts.springbootjpa;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="Category_details")
public class Category implements Serializable {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int categoryid;
	private String categoryname;
	private String briefdetails;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="CATEGORY_ID")
	private List<SubCategory> subcategory;
	public Category() {
		
	}

	public Category(int categoryid, String categoryname, String briefdetails) {
		super();
		this.categoryid = categoryid;
		this.categoryname = categoryname;
		this.briefdetails = briefdetails;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getBriefdetails() {
		return briefdetails;
	}

	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}
	
	

	public List<SubCategory> getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(List<SubCategory> subcategory) {
		this.subcategory = subcategory;
	}

	@Override
	public String toString() {
		return "Category [categoryid=" + categoryid + ", categoryname=" + categoryname + ", briefdetails="
				+ briefdetails + "]";
	}
	
	

}
