package com.cts.springbootjpa;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table
public class Discounts implements Serializable  {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int discountid;
	private int discountcode;
	private float percentage;
	private Date startdate;
	private Date enddate;
	private String description;
	
	public Discounts() {
		
		
	}
	public Discounts(int discountid, int discountcode, float percentage, Date startdate, Date enddate,
			String description) {
		super();
		this.discountid = discountid;
		this.discountcode = discountcode;
		this.percentage = percentage;
		this.startdate = startdate;
		this.enddate = enddate;
		this.description = description;
	}


	public int getDiscountid() {
		return discountid;
	}


	public void setDiscountid(int discountid) {
		this.discountid = discountid;
	}


	public int getDiscountcode() {
		return discountcode;
	}


	public void setDiscountcode(int discountcode) {
		this.discountcode = discountcode;
	}


	public float getPercentage() {
		return percentage;
	}


	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}


	public Date getStartdate() {
		return startdate;
	}


	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}


	public Date getEnddate() {
		return enddate;
	}


	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "Discounts [discountid=" + discountid + ", discountcode=" + discountcode + ", percentage=" + percentage
				+ ", startdate=" + startdate + ", enddate=" + enddate + ", description=" + description + "]";
	}
	
	
	
	
}
