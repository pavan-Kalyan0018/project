package com.CartegoryRelationship.cart;

public class PurchaseHistory {

}
